﻿using UnityEngine;
using KSP.UI.Screens;

namespace DangerMod
{
    [KSPAddon(KSPAddon.Startup.Flight, false)]
    public class DangerMod : MonoBehaviour
    {
        private ApplicationLauncherButton? button;
        private Texture2D? icon;

        private bool showWindow = false;
        private Rect windowRect = new Rect(300, 100, 300, 200);

        public void Start()
        {
            icon = GameDatabase.Instance.GetTexture(
                "DangerMod/Textures/icon",
                false
            );

            if (ApplicationLauncher.Ready && icon != null)
            {
                button = ApplicationLauncher.Instance.AddModApplication(
                    ToggleWindow,
                    ToggleWindow,
                    null,
                    null,
                    null,
                    null,
                    ApplicationLauncher.AppScenes.FLIGHT,
                    icon
                );

                Debug.Log("[Danger Mod] Loaded!");
            }
        }

        private void ToggleWindow()
        {
            showWindow = !showWindow;
        }

        public void OnGUI()
        {
            if (showWindow)
            {
                windowRect = GUILayout.Window(
                    GetInstanceID(),
                    windowRect,
                    DrawWindow,
                    "Danger Mod"
                );
            }
        }

        private void DrawWindow(int windowID)
        {
            GUILayout.Label("🌩️ Danger Mod");

            GUILayout.Space(10);

            GUILayout.Label("Storm Status:");
            GUILayout.Label("No Storm Detected");

            GUILayout.Space(10);

            if (GUILayout.Button("Test Warning"))
            {
                ScreenMessages.PostScreenMessage(
                    "DANGER ON 5000m!",
                    5f,
                    ScreenMessageStyle.UPPER_CENTER
                );

                Debug.Log("[Danger Mod] Test Warning");
            }

            GUI.DragWindow();
        }

        public void OnDestroy()
        {
            if (button != null)
            {
                ApplicationLauncher.Instance.RemoveModApplication(button);
            }
        }
    }
}